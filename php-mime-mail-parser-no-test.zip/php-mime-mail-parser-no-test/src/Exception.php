<?php

namespace PhpMimeMailParser;

/**
 * @see \Tests\PhpMimeMailParser\ExceptionTest
 */
final class Exception extends \RuntimeException
{
}
