<?php

namespace PhpMimeMailParser\Trait;

trait BackupTrait
{
//    /**
//     * TODO: to remove
//     *
//     * @return string|null
//     */
//    private function getCharsetFormOtherFields()
//    {
//        if (strtolower($this->getContentTransferEncoding()) === '8bit') {
//            return 'windows-1252';
//        }
//        if (strtolower($this->getContentTransferEncoding()) === '7bit') {
//            return 'iso-8859-1';
//        }
//        return null;
//    }
}
